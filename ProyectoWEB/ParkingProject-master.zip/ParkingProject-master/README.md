# ParkingProject
It will be a system for a parking in Bucaramanga, Colombia. Based principaly on Python and SQL for the Database.
