import os
os.startfile("/Documents/ParkingProject/BackEnd/Factura_Entrada.pdf", "print")
